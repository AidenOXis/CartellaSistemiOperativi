#ifndef _HEADER_MSG_H_
#define _HEADER_MSG_H_

#include <sys/types.h>

/* TBD: Definire i valori per i campi-tipo dei messaggi */
#define PRODUZIONE 3
#define CONSUMAZIONE 4 //Aggiungo le macro 
#define ACK 1
#define CONNECT 2

typedef struct {
    
    /* TBD: Definire la struttura del messaggio,
            includendo un campo per inserire il PID del mittente
     */
    long type; 
    long pid; 

} messaggio_connect;

typedef struct {

    /* TBD: Definire la struttura del messaggio,
            includendo un campo per inserire l'ID della coda di richieste,
            e un campo per inserire l'ID della coda di risposte.
     */
    long pid; 
    long type;
    int id_coda_richieste;
    int id_coda_risposte;

} messaggio_ack;

typedef struct {
    
    /* TBD: Definire la struttura del messaggio,
            includendo un campo per inserire un valore intero.
    */
   long type; 
   int valore; 

} messaggio_richiesta;

typedef struct {

    /* TBD: Definire la struttura del messaggio,
            includendo un campo per inserire un valore intero.
    */
   long type; 
   int valore; 

} messaggio_risposta;

#endif