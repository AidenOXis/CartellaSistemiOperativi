#include <stdio.h>
#include <unistd.h>
#include <sys/wait.h>
#include <stdlib.h>
#include <sys/ipc.h>
#include <sys/msg.h>

int main() {
        
        int pid; 
   

    /* TBD: Creare la coda di messaggi per
            i messaggi di tipo "connect"
     */
    key_t key_connect = ftok(".",'a');
    int id_connect = msgget(key_connect,IPC_CREAT|0664);
    


    /* TBD: Creare la coda di messaggi per
            i messaggi di tipo "acknowledge"
     */
    key_t key_ack = ftok(".",'b');
    int id_ack = msgget(key_ack,IPC_CREAT | 0664);


    /* TBD: Creare un processo figlio,
            e fargli eseguire il programma "server"
     */
    pid_t pid; 
    pid = fork(); 
    if(pid == 0 ){
        execl("./server","server",NULL);

    }


    /* TBD: Creare due processi figli,
            e fargli eseguire il programma "client"
     */
    pid = fork();
    for(int i = 0 ; i<2; i++){
        if(pid == 0){
                execl("./client","client",NULL);
        }
    }

    /* TBD: Attendere la terminazione dei 3 processi figli */
    for(int i =0; i<3; i++){
        wait(NULL);
    }

    /* TBD: De-allocare le due code di messaggi */
    msgctl(id_ack,IPC_RMID,NULL);
    msgctl(id_connect,IPC_RMID,NULL);

}