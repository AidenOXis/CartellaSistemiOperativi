#ifndef _HEADER_MONITOR_H_
#define _HEADER_MONITOR_H_

#include <pthread.h>

#define DIM 5



typedef struct {

    int buffer[DIM];

    /* TBD: Aggiungere le variabili testa/coda per il vettore circolare */
    int coda; 
    int testa; 
    int count; 
    /* TBD: Aggiungere le variabili per la sincronizzazione */
    pthread_mutex_t mutex; 
    pthread_cond_t cv_prod;
    pthread_cond_t cv_cons;

    //aggiungo i thread 
    int thread_cons;
    int thread_prod;
    

} MonitorPC;

void init_monitorpc(MonitorPC *p);
void remove_monitorpc(MonitorPC *p);
void produci(MonitorPC *p, int val);
int consuma(MonitorPC *p);

#endif