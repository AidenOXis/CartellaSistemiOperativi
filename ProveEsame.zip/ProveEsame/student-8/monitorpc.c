#include "header_monitor.h"

void init_monitorpc(MonitorPC *p) {

    /* TBD: Inizializzare le variabili testa/coda per il vettore circolare */
    p->testa = 0; 
    p->coda = 0; 
    p->count = 0; 

    p->thread_prod=0; 
    p->thread_cons=0; 
    /* TBD: Inizializzare le variabili per la sincronizzazione */
    pthread_mutex_init(&p->mutex,NULL);
    pthread_cond_init(&p->cv_cons,NULL);
    pthread_cond_init(&p->cv_prod,NULL);
}

void remove_monitorpc(MonitorPC *p) {

    /* TBD: De-inizializzare le variabili per la sincronizzazione */
    pthread_mutex_destroy(&p->mutex);
    pthread_cond_destroy(&p->cv_cons);
    pthread_cond_destroy(&p->cv_prod);

}

void produci(MonitorPC *p, int val) {
    //aggiungo il mutex
    pthread_mutex_lock(&p->mutex);

    /* TBD: Completare il metodo con la sincronizzazione
            e con la gestione della coda circolare
     */
    while(p->count == DIM){
        p->thread_prod++;
        pthread_cond_wait(&p->cv_cons,&p->mutex);
        p->thread_prod--;
    }
    pthread_mutex_unlock(&p->mutex);

    pthread_mutex_lock(&p->mutex);

    p->buffer[p->coda/* TBD */] = val;
    p->coda = (p->coda + 1) %DIM;
    p->count ++; 

    pthread_cond_signal(&p->cv_cons);
    pthread_mutex_unlock(&p->mutex);


}

int consuma(MonitorPC *p) {

    int val;

    pthread_mutex_lock(&p->mutex);
    /* TBD: Completare il metodo con la sincronizzazione
            e con la gestione della coda circolare
     */
    while(p->count == 0 ){
        p->thread_cons++;
        pthread_cond_wait(&p->cv_prod,&p->mutex);
        p->thread_cons--;
    }
    pthread_mutex_unlock(&p->mutex);

    pthread_mutex_lock(&p->mutex);
    val = p->buffer[p->testa/* TBD */];
    p->testa = (p->testa + 1) %DIM;
    p->count --; 

    pthread_cond_signal(&p->cv_prod);
    pthread_mutex_unlock(&p->mutex);


    return val;
}
