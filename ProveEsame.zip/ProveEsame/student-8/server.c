#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/ipc.h>
#include <sys/msg.h>

#include "header_msg.h"
#include "header_monitor.h"


void * thread_worker(void *);

int main() {

    srand(getpid());


    /* TBD: Ottenere le due code di messaggi "connect" ed "ack"
            (le stesse create nel programma "start")
     */

     key_t connect_key = ftok(".",'a');

    int id_connect = msgget(id_connect, 0664)/* TBD */;
    if(id_connect < 0){
        perror("Errore");
        exit(1);
    }

    key_t ack_key= ftok(".",'b');

    int id_ack = msgget(id_ack,0664)/* TBD */;
    if(id_ack<0){
        perror("Errore");
        exit(1);
    }



    MonitorPC *p = malloc(sizeof(MonitorPC))/* TBD: Allocare e inizializzare un oggetto monitor */;
    init_monitorpc(p);

    pthread_t worker[2];


    // Ripete per 2 client

    for(int i=0; i<2; i++) {

        /* TBD: Attendere un messaggio "connect" */
        messaggio_connect msg_connect;
        msg_connect.type = CONNECT;
        int ret = msgrcv(id_connect,&msg_connect,sizeof(messaggio_connect)-sizeof(long),CONNECT,0);
        if(ret <0){
            perror("Errore");
            exit(1);
        }

        pid_t pid = msg_connect.pid;/* TBD: Estrarre il PID del client dal messaggio "connect" */;
        

        int id_coda_richieste = msgget(IPC_PRIVATE,IPC_CREAT | 0664); /* TBD: Creare una coda di richieste, dedicata alla nuova connessione */
        if (id_coda_richieste < 0) {
            perror("Errore creazione coda richieste");
            exit(1);
        }


        int id_coda_risposte = msgget(IPC_PRIVATE,IPC_CREAT | 0664);/* TBD: Creare una coda di risposte, dedicata alla nuova connessione */
        if (id_coda_risposte < 0) {
            perror("Errore creazione coda risposte");
            exit(1);
        }


        /* TBD: Inviare un messaggio "ack", contenente gli ID delle code di richieste e risposte */
        messaggio_ack msg_ack;
        msg_ack.type =ACK;
        msg_ack.id_coda_richieste = id_coda_richieste;
        msg_ack.id_coda_risposte = id_coda_risposte;
        int rc = msgsnd(id_ack,&msg_ack,sizeof(messaggio_ack)-sizeof(long),0);
        if(rc < 0 ){
            perror("Errore");
            exit(1);
        }

        printf("[SERVER] Connesso client %d\n", pid);


        /* TBD: Creare un thread worker, che esegua la funzione
                "thread_worker()".

                Passare come input al thread
                le seguenti variabili:
                - id coda richieste
                - id coda risposte
                - oggetto monitor
                - PID del client
        */
        typedef struct {
            int id_coda_richieste;
            int id_coda_risposte;
            MonitorPC *p;
            pid_t pid;
        } thread_args;

        thread_args *args = (thread_args *)malloc(sizeof(thread_args));
        args->id_coda_richieste = id_coda_richieste;
        args->id_coda_risposte = id_coda_risposte;
        args->p = p;
        args->pid = pid;


       int rc = pthread_create(&worker[i],NULL,thread_worker,(void *)p);


    }

    for(int i=0; i<2; i++) {

        /* TBD: Attendere la terminazione dei thread */
        remove_monitorpc(p);
        free(p);
    }


    /* TBD: Deallocare l'oggetto monitor */
    remove_monitorpc(p);
    free(p);

}


void * thread_worker(void * arg) {

    /* TBD: Completare il passaggio dei parametri */
      typedef struct {
            int id_coda_richieste;
            int id_coda_risposte;
            MonitorPC *p;
            pid_t pid;
        } thread_args;

    thread_args *args =(thread_args *)arg;

    int id_coda_richieste =args->id_coda_richieste /* TBD */;
    int id_coda_risposte =args->id_coda_risposte /* TBD */;
    MonitorPC *p = args->p/* TBD */;
    pid_t pid = args->pid/* TBD */;


    // Ogni worker serve 6 richieste, e poi termina

    for(int i=0; i<6; i++) {

        printf("[SERVER] In attesa di richiesta dal client %d\n", pid);


        /* TBD: Attendere un messaggio dalla coda delle richieste */
        messaggio_richiesta msg_req;
        if (msgrcv(id_coda_richieste, &msg_req, sizeof(messaggio_richiesta) - sizeof(long), 0, 0) < 0) {
            perror("Errore ricezione richiesta");
            pthread_exit(NULL);
        }
        if(msg_req.type == PRODUZIONE/* TBD: Richiesta di tipo "PRODUZIONE" */) {

            printf("[SERVER] Richiesta di produzione dal client %d\n", pid);


            int valore = msg_req.valore/* TBD: Estrarre il valore dal messaggio di richeista*/;

            /* TBD: Chiamare il metodo produci(), passando in ingresso "valore" */
            produci(p,msg_req.valore);

            printf("[SERVER] Valore prodotto: %d (client %d)\n", valore, pid);



            /* TBD: Inviare un messaggio di risposta di tipo "PRODUZIONE", con valore 0 */
            messaggio_risposta msg_ris;
            msg_ris.type = PRODUZIONE;
            msg_ris.valore = 0;
            int ret = msgsnd(id_coda_risposte,&msg_ris,sizeof(messaggio_risposta)-sizeof(long),0);
            if(ret<0){
                perror("Error");
                exit(1);
            }
            printf("[SERVER] Risposta inviata al client %d\n", pid);

        }
        else if(msg_req.type == CONSUMAZIONE/* TBD: Richiesta di tipo "CONSUMAZIONE" */) {

            printf("[SERVER] Richiesta di consumazione dal client %d\n", pid);

            int valore = consuma(p) /* TBD: Chiamare il metodo consuma() */;

            printf("[SERVER] Valore consumato: %d (client %d)\n", valore, pid);



            /* TBD: Inviare un messaggio di risposta di tipo "CONSUMAZIONE", con il valore consumato */
            messaggio_risposta msg_risp;
            msg_risp.type = CONSUMAZIONE;
            msg_risp.valore = valore;
            int ret = msgsnd(id_coda_risposte,&msg_risp,sizeof(messaggio_risposta)-sizeof(long),0);
            if(ret<0){
                perror("Error");
                exit(1);
            }
            printf("[SERVER] Risposta inviata al client %d\n", pid);

        }
    }


    pthread_exit(NULL);
}