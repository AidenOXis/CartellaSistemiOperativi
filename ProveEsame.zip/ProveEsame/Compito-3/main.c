#include "prodcons.h"
#include <stdio.h>
#include <stdlib.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys/wait.h>
#include <unistd.h>
#include <string.h>
#include <time.h>

void Produttore(MonitorStreaming *p);
void Consumatore(MonitorStreaming *p);

int main() {
    // Creazione shared memory per il monitor
    int id_shm = shmget(IPC_PRIVATE, sizeof(MonitorStreaming), IPC_CREAT|0664);
    if(id_shm == -1) {
        perror("Errore creazione shared memory monitor");
        exit(1);
    }

    MonitorStreaming * p = shmat(id_shm, NULL, 0);
    if(p == (void*)-1) {
        perror("Errore attach shared memory monitor");
        shmctl(id_shm, IPC_RMID, NULL);
        exit(1);
    }

    inizializza(p);

    // Creazione processo produttore
    pid_t pid = fork();
    if(pid == -1) {
        perror("Errore fork produttore");
        exit(1);
    }
    if(pid == 0) {
        srand(time(NULL) ^ getpid());  // Migliore inizializzazione random
        Produttore(p);
        exit(0);
    }
    
    // Creazione processo consumatore
    pid = fork();
    if(pid == -1) {
        perror("Errore fork consumatore");
        exit(1);
    }
    if(pid == 0) {
        Consumatore(p);
        exit(0);
    }

    // Attesa terminazione processi
    for(int i = 0; i < 2; i++) {
        wait(NULL);
    }
    
    // Pulizia risorse
    distruggi(p);
    shmdt(p);
    shmctl(id_shm, IPC_RMID, NULL);
    
    return 0;
}

void Produttore(MonitorStreaming *p) {
    char stringa[20];
    size_t lunghezza;
    key_t chiave;
    int proj_id = 1;  // Identificatore progetto per ftok

    for(int i = 0; i < 10; i++) {
        // Genera lunghezza casuale (tra 5 e 15 per sicurezza)
        lunghezza = 5 + rand() % 11;

        // Genera stringa casuale
        for(int j = 0; j < lunghezza-1; j++) {
            stringa[j] = 'a' + (rand() % 26);
        }
        stringa[lunghezza-1] = '\0';

        // Genera chiave unica
        chiave = ftok(".", proj_id++);
        if(chiave == -1) {
            perror("Errore generazione chiave");
            continue;
        }

        printf("Produttore: generata stringa '%s'\n", stringa);
        produci(p, stringa, lunghezza, chiave);

        sleep(1);
    }
}

void Consumatore(MonitorStreaming *p) {
    char stringa[20];
    size_t lunghezza;

    for(int i = 0; i < 10; i++) {
        consuma(p, stringa, &lunghezza);
        printf("Consumatore: letta stringa '%s'\n", stringa);
        sleep(1);
    }
}
