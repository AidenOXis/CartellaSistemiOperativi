// prodcons.c
#include "prodcons.h"
#include <stdio.h>
#include <stdlib.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <string.h>
#include <unistd.h>

void inizializza(MonitorStreaming * p) {
    if (p == NULL) return;

    init_monitor(&p->monitor, NUM_VAR_COND);

    for(int i = 0; i < DIM; i++) {
        p->vettore[i].stato = LIBERO;
        p->vettore[i].produttore = 0;
        p->vettore[i].dimensione = 0;
        p->vettore[i].chiave = 0;
    }
    
    p->testa = 0;
    p->coda = 0;
    p->count = 0;
}

void produci(MonitorStreaming * p, char * stringa, size_t lunghezza, key_t chiave) {
    if (p == NULL || stringa == NULL) return;

    enter_monitor(&p->monitor);

    printf("Produttore [%d]: Avvio produzione...\n", getpid());
    
    while (p->count == DIM) {
        wait_condition(&p->monitor, CV_PRODUTTORE);
    }

    // Trova il primo slot libero
    while (p->vettore[p->testa].stato != LIBERO) {
        p->testa = (p->testa + 1) % DIM;
    }

    // Marca lo slot come in uso
    p->vettore[p->testa].stato = IN_USO;

    // Crea e attacca la shared memory per il frame
    int shmid = shmget(chiave, lunghezza + 1, IPC_CREAT | 0664);
    if (shmid == -1) {
        perror("Errore creazione shared memory per frame");
        p->vettore[p->testa].stato = LIBERO;
        leave_monitor(&p->monitor);
        return;
    }

    char * stringa_shm = shmat(shmid, NULL, 0);
    if (stringa_shm == (char *)-1) {
        perror("Errore attach shared memory per frame");
        p->vettore[p->testa].stato = LIBERO;
        shmctl(shmid, IPC_RMID, NULL);
        leave_monitor(&p->monitor);
        return;
    }

    // Copia i dati
    strcpy(stringa_shm, stringa);
    shmdt(stringa_shm);

    // Aggiorna il buffer
    p->vettore[p->testa].dimensione = lunghezza;
    p->vettore[p->testa].chiave = chiave;
    p->vettore[p->testa].produttore = getpid();
    p->vettore[p->testa].stato = OCCUPATO;

    p->testa = (p->testa + 1) % DIM;
    p->count++;

    signal_condition(&p->monitor, CV_CONSUMATORE);
    leave_monitor(&p->monitor);
}

void consuma(MonitorStreaming * p, char * stringa, size_t * lunghezza) {
    if (p == NULL || stringa == NULL || lunghezza == NULL) return;

    enter_monitor(&p->monitor);

    printf("Consumatore [%d]: Avvio consumazione...\n", getpid());
    
    while (p->count == 0) {
        wait_condition(&p->monitor, CV_CONSUMATORE);
    }

    while (p->vettore[p->coda].stato != OCCUPATO) {
        p->coda = (p->coda + 1) % DIM;
    }

    p->vettore[p->coda].stato = IN_USO;

    key_t chiave = p->vettore[p->coda].chiave;
    *lunghezza = p->vettore[p->coda].dimensione;

    int shmid = shmget(chiave, *lunghezza + 1, 0664);
    if (shmid == -1) {
        perror("Errore accesso shared memory frame");
        p->vettore[p->coda].stato = LIBERO;
        leave_monitor(&p->monitor);
        return;
    }

    char * stringa_shm = shmat(shmid, NULL, 0);
    if (stringa_shm == (char *)-1) {
        perror("Errore attach shared memory frame");
        p->vettore[p->coda].stato = LIBERO;
        leave_monitor(&p->monitor);
        return;
    }

    strcpy(stringa, stringa_shm);
    shmdt(stringa_shm);
    shmctl(shmid, IPC_RMID, NULL);

    p->vettore[p->coda].stato = LIBERO;
    p->coda = (p->coda + 1) % DIM;
    p->count--;

    signal_condition(&p->monitor, CV_PRODUTTORE);
    leave_monitor(&p->monitor);
}

void distruggi(MonitorStreaming * p) {
    if (p == NULL) return;

    for(int i = 0; i < DIM; i++) {
        if(p->vettore[i].stato != LIBERO) {
            int shmid = shmget(p->vettore[i].chiave, p->vettore[i].dimensione + 1, 0664);
            if(shmid != -1) {
                shmctl(shmid, IPC_RMID, NULL);
            }
        }
    }
    remove_monitor(&p->monitor);
}
