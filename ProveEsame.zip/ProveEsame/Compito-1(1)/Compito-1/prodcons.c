#include "prodcons.h"
#include <stdio.h>
#include <pthread.h>
#include <stdlib.h>

void inizializza(MonitorStreaming * m) {
    pthread_mutex_init(&m->mutex, NULL);
    pthread_cond_init(&m->cv_prod, NULL); 
    pthread_cond_init(&m->cv_cons, NULL);
    m->disponi = 0;
}

void produci(MonitorStreaming * m, Frame f) {
    pthread_mutex_lock(&m->mutex); 

    while(m->disponi == DIM) {
        pthread_cond_wait(&m->cv_prod, &m->mutex); 
    }

    // Copia del frame nel buffer
    m->vettore[m->disponi][0][0] = f[0][0];
    m->vettore[m->disponi][0][1] = f[0][1];
    m->vettore[m->disponi][1][0] = f[1][0];
    m->vettore[m->disponi][1][1] = f[1][1];

    printf("Produzione frame: { %d, %d, %d, %d }\n", 
           f[0][0], f[0][1], f[1][0], f[1][1]);

    m->disponi++;  
    pthread_cond_signal(&m->cv_cons);  
    pthread_mutex_unlock(&m->mutex); 
}

void consuma(MonitorStreaming * m, Frame f) {
    pthread_mutex_lock(&m->mutex);

    while(m->disponi == 0) {
        pthread_cond_wait(&m->cv_cons, &m->mutex);
    }

    m->disponi--;
    
    // Copia dal buffer
    f[0][0] = m->vettore[m->disponi][0][0];
    f[0][1] = m->vettore[m->disponi][0][1];
    f[1][0] = m->vettore[m->disponi][1][0];
    f[1][1] = m->vettore[m->disponi][1][1];

    printf("Consumazione frame: { %d, %d, %d, %d }\n", 
           f[0][0], f[0][1], f[1][0], f[1][1]);
    
    pthread_cond_signal(&m->cv_prod);  
    pthread_mutex_unlock(&m->mutex); 
}

void bufferizza(MonitorStreaming * m, int n) {
    Frame f;
    for(int i = 0; i < n && i < DIM; i++) {  // Aggiungiamo controllo su DIM
        f[0][0] = rand() % 11;
        f[0][1] = rand() % 11;
        f[1][0] = rand() % 11;
        f[1][1] = rand() % 11;
        produci(m, f);
    }
}

void distruggi(MonitorStreaming * m) {
    pthread_mutex_destroy(&m->mutex);
    pthread_cond_destroy(&m->cv_prod);
    pthread_cond_destroy(&m->cv_cons);
}
