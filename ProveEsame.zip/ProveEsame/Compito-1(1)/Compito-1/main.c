#include "prodcons.h"
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>

void * Produttore(void *);
void * Consumatore(void *);

int main() {
    MonitorStreaming monitor; 
    inizializza(&monitor);  // Inizializzazione necessaria
    
    pthread_t prod_thread;
    pthread_t cons_thread; 
   
    pthread_create(&prod_thread, NULL, Produttore, &monitor);
    pthread_create(&cons_thread, NULL, Consumatore, &monitor);
    
    pthread_join(prod_thread, NULL); 
    pthread_join(cons_thread, NULL); 

    distruggi(&monitor);
    return 0; 
}

void * Produttore(void * p) {
    MonitorStreaming * monitor = (MonitorStreaming *)p; 
    
    for(int i = 0; i < 10; i++) {
        Frame f;
        f[0][0] = rand() % 11;
        f[0][1] = rand() % 11;
        f[1][0] = rand() % 11;
        f[1][1] = rand() % 11;

        produci(monitor, f);
        sleep(1);
    }
    
    pthread_exit(NULL);
}

void * Consumatore(void * p) {
    MonitorStreaming * monitor = (MonitorStreaming *)p;

    for(int i = 0; i < 10; i++) {
        Frame f;
        consuma(monitor, f);
        sleep(1);
    }

    pthread_exit(NULL);
}
